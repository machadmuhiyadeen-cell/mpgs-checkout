// /api/create-session.js
import fetch from "node-fetch";

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { amount, currency, orderId, description } = req.body || {};

    const MERCHANT_ID = process.env.MPGS_MERCHANT_ID;
    const API_PASSWORD = process.env.MPGS_API_PASSWORD;
    const GATEWAY_BASE = process.env.MPGS_BASE || "https://eu-gateway.mastercard.com";
    const API_VERSION = process.env.MPGS_API_VERSION || "100";
    const PUBLIC_BASE = process.env.PUBLIC_BASE_URL;

    if (!MERCHANT_ID || !API_PASSWORD || !PUBLIC_BASE) {
      return res.status(400).json({ error: "Missing required environment variables." });
    }

    const ordId = orderId || `ORD-${Date.now()}`;
    const amt = Number(amount ?? 49).toFixed(2);
    const curr = (currency || "EUR").toUpperCase();
    const desc = description || "Order";

    const createUrl = `${GATEWAY_BASE}/api/rest/version/${API_VERSION}/merchant/${MERCHANT_ID}/session`;
    const auth = Buffer.from(`merchant.${MERCHANT_ID}:${API_PASSWORD}`).toString("base64");

    const body = {
      apiOperation: "CREATE_CHECKOUT_SESSION",
      order: {
        id: ordId,
        amount: amt,
        currency: curr,
        description: desc
      },
      interaction: {
        operation: "PURCHASE",
        returnUrl: `${PUBLIC_BASE}/return?orderId=${encodeURIComponent(ordId)}`,
        cancelUrl: `${PUBLIC_BASE}/cancel?orderId=${encodeURIComponent(ordId)}`
      }
    };

    const resp = await fetch(createUrl, {
      method: "POST",
      headers: {
        "Authorization": `Basic ${auth}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body)
    });

    const data = await resp.json();

    if (!resp.ok) {
      return res.status(resp.status).json({ error: data });
    }

    return res.status(200).json({
      sessionId: data?.session?.id,
      merchant: MERCHANT_ID,
      orderId: ordId,
      amount: amt,
      currency: curr
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "server_error" });
  }
}
